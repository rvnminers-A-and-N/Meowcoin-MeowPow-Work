class SeedsNotFound(Exception):
    pass


class ZoneNotFound(Exception):
    pass


class TooManyZones(Exception):
    pass
